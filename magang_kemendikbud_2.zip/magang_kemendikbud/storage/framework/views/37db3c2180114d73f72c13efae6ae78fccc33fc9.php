;
<?php $__env->startSection('title', 'Halo Ashari'); ?>;

<?php $__env->startSection('content'); ?>
<br>
<br>
<br>
<br>
<br>
<br>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Formulr Pelayanan</div>
 
                <div class="card-body">
                    <form method="POST" action="/form">
                        <?php echo csrf_field(); ?>
 
                        <div class="form-group">
                            <label>Nama Lengkap</label>
                            <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>">
                        </div>
                        <div class="form-group">
                            <label>Alamat</label>
                            <textarea name="address" class="form-control" cols="30" rows="10"><?php echo e(old('address')); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label>Instansi</label>
                            <input type="text" class="form-control" name="name" value="<?php echo e(old('instansi')); ?>">
                        </div>
                        <div class="form-group">
                            <label>No KTP / SIM</label>
                            <input type="text" class="form-control" name="name" value="<?php echo e(old('noktp')); ?>">
                        </div>
                        <div class="form-group">
                            <label>No Telepon</label>
                            <input type="text" class="form-control" name="name" value="<?php echo e(old('nohp')); ?>">
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>">
                        </div>
                        <div>
                            <label>Pilih Loket yang dituju</label>
                            <select type="text" class="form-control" name="name" value="<?php echo e(old('loket')); ?>">
                              <option selected>Loket yang dituju</option>
                              <option value="1">Loket 1</option>
                              <option value="2">Loket 2</option>
                              <option value="3">Loket 3</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Keperluan</label>
                            <textarea name="keperluan" class="form-control" cols="30" rows="10"><?php echo e(old('keperluan')); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label>Tanggal Lahir</label>
                            <input type="date" class="form-control" name="dob" value="<?php echo e(old('dob')); ?>">
                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary">Simpan</button>
                        </div>
 
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\magang_kemendikbud\resources\views/pages/form.blade.php ENDPATH**/ ?>