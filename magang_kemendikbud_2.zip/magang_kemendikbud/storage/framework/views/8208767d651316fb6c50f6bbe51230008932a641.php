
<!DOCTYPE html>
<html>
<style>
body {
  font-size: 20px;
}
</style>
<body>

<span style='font-size:100px;'>&#128525;</span>
<p>I will display &#128525;</p>

<span style='font-size:100px;'>&#128561;</span>
<p>I will display &#128561;</p>

<span style='font-size:100px;'>&#129324;</span>
<p>I will display &#129324;</p>

<span style='font-size:100px;'>&#128512;</span>
<p>I will display &#128512;</p>

<span style='font-size:100px;'>&#128514;</span>
<p>I will display &#128514;</p>

</body>
</html><?php /**PATH C:\xampp\htdocs\magang_kemendikbud\resources\views/pages/feedback.blade.php ENDPATH**/ ?>