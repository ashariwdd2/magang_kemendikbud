
@extends('layouts.main');
<br>
<br>
<br>
<br>
<br>
<br>
<div class="row justify-content-center">
<span style='font-size:50px;'>TERIMA KASIH</span>

</div>

