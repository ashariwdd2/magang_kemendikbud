;
<?php $__env->startSection('title', 'ULT'); ?>;

<?php $__env->startSection('content'); ?>
    <!-- ======= Hero Section ======= -->
    <section id="hero">

    <div class="container">
    <div class="row">
        <div class="col-lg-6 pt-5 pt-lg-0 order-2 order-lg-1 d-flex flex-column justify-content-center" data-aos="fade-up">
        <div>
            <h1>Unit Layanan Terpadu</h1>
            <h2>LEMBAGA LAYANAN PENDIDIKAN TINGGI WILAYAH V Yogyakarta</h2>
            <a href="<?php echo e(route('form')); ?>" class="btn-get-started scrollto">Isi Formulir</a>
        </div>
        </div>
        <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="fade-left">
        <img src="assets/img/kemendikbudlogo.png" class="img-fluid" alt="Logo Kemendikbud">
        </div>
    </div>
    </div>

    </section><!-- End Hero -->
    <br>
    <br>

    <main id="main">
        <div class="kartu">
            <div class="kartu-container">
                <div class="cards card-1">
                  <div class="kartu-content">
                    <h3><a href="#">Loket Sumber Daya</a></h3>
                    <p>Loket yang melayani tentang Sumber Daya pendidikan.</p>
                    <a href="#" class="kartu-btn">Deskripsi</a>
                  </div>
                  <div class="kartu-tags">
                    <a href="#" class="kartu-btn">Loket 1</a>
                  </div>
                </div>
                <div class="cards card-2">
                  <div class="kartu-content">
                    <h3><a href="#">Loket Akademik Kemahasiswaan</a></h3>
                    <p>Loket yang melayani Bagian Akademik Kemahasiswaan</p>
                    <a href="#" class="kartu-btn">Deskripsi</a>
                  </div>
                  <div class="kartu-tags">
                    <a href="#" class="kartu-btn">Loket 2</a>
                  </div>
                </div>
                <div class="cards card-3">
                  <div class="kartu-content">
                    <h3><a href="#"> Loket Kelembagaan</a></h3>
                    <p>Loketyang melayani bagian Kelembagaan Pendidikan.</p>
                    <a href="#" class="kartu-btn">Deskripsi</a>
                  </div>
                  <div class="kartu-tags">
                    <a href="#" class="kartu-btn">Loket 2</a>
                  </div>
                </div>
            </div>
        </div>
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\magang_kemendikbud-master\resources\views/welcome.blade.php ENDPATH**/ ?>